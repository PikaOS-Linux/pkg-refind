#!/usr/bin/env perl

foreach $i (32..126) {
  print chr($i);
}
print "?\n";
exit 0;
